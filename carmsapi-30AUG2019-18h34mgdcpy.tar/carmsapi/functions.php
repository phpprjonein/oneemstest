<?php

function logToFile($filename, $msg) {
    // open file
    $fd = fopen($filename, "a");
    // append date/time to message
    $str = "[" . date("Y/m/d h:i:s", mktime()) . "] " . $msg;
    // write string
    fwrite($fd, $str . "\n");
    // close file
    fclose($fd);
}

	function getUser($name) {
			global $db2;	
			//$sql = "SELECT id, p.name, p.description, p.price, p.created FROM items p WHERE p.name LIKE '%".$name."%' ORDER BY p.created DESC";
				//$sql = "select id, username, password, userlevel,fname,lname,phone from users p WHERE p.username = '".$name."'"; 
				$sql = "select id, username, userlevel from users p WHERE p.username = '".$name."'"; 
				$db2->query($sql);
			   $resultset['result'] = $db2->resultset();
				return  $resultset['result'];    
	}
			  //[username] => ssf [password] => k [usertype] => k [firstname] => k [lastname] => k [phoneno] => k [emailid] => k ) 
	function addUser($data) {
			global $db2;	
			$sql = "insert into users (username, password, userid, userlevel, email, status, fname, lname, phone ) values ('".$data['username']."','".md5($data['password'])."','".$data['username']."','".$data['usertype']."','".$data['emailid']."','1','".$data['firstname']."','".$data['lastname']."','".$data['phoneno']."')"; 
			 //$data = array("username" => $_POST['uname'],"password" => $_POST['passwd'],"usertype" => $_POST['usertype'],"firstname"=>$_POST['firstname'],"lastname" => $_POST['lname'],"phoneno" => $_POST['phoneno'],"emailid" => $_POST['emailid']);
			    //$sql = "insert into users ( username, password, userid, userlevel, email, fname, lname, phone ) values ('".$data['username']."''".$data['password']."''"..$data['userid']."''".$data['userlevel']."''".$data['email']."''".$data['fname']."''".$data['lname']."''".$data['phoneno']."')";
			   $db2->query($sql);
			   $result=$db2->execute();
			   
			    //$resultset['result'] = $db2->resultset();
				//return  $resultset['result'];    
				 return $result;
				  //$data = json_decode($data);
				 // echo $result;  
				 //print_r($data);
				 //echo json_encode($sql);
	} 
		
	function addregengnrmarket($data){
		global $db2;
		$sql = "insert into regengnrmarket (username, market) values ('".$data['username']."','".$data['market']."')"; 
			 
		$db2->query($sql);
		$result=$db2->execute();
		
		return $result;
	}
	
	function deleteUser($data) {
		global $db2;	
		$user = getUser($data['username']);
		$sql = "delete from users where username = '".$data['username']."'";  
		$db2->query($sql);
		$result=$db2->execute(); 
		//if($user['userlevel']==5)
		//{
			$sql1 = "delete from regengnrmarket where username = '".$data['username']."'";  
			$db2->query($sql1);
			$result1=$db2->execute(); 
			$sql1 = "delete from users where username = '".$data['username']."'";  
			$db2->query($sql1);
			$result1=$db2->execute(); 
		//}
		return $result; 
			
	}  

     // Begins
        function getMarkets($name) {
                        global $db2;
                                $sql = "select market from regengnrmarket p WHERE p.username = '".$name."'";
                                $db2->query($sql);
                           //$resultset['result'] = $db2->resultset();
                           $resultset = $db2->resultset();
                                //return  $resultset['result'];
                                //print_r($resultset); exit();
                                return  $resultset;
        }

      //Ends

	function updateMarkets($data) {
	 global $db2;	
	  $sql = "delete from regengnrmarket p WHERE p.username = '".$data['username']."'"; 
	   $db2->query($sql);
			$result1=$db2->execute(); 
			//$sql = "insert into regengnrmarket (username, markets ) values ('".$data['username']."','".$data['markets'])."')"; 
			$sql = "insert into regengnrmarket (username, markets ) values ('".$data['username']."','".$data['markdets']."')";
			$db2->query($sql);
			$result=$db2->execute();
	}

function getregengnrmarket($data) {
		global $db2;	
		$name=$data['username'];
		$market=$data['market'];
		if(!isset($market))
			$sql = "select market, username from regengnrmarket m WHERE m.username = '".$name."'";
		else		
			$sql = "select market, username from regengnrmarket m WHERE m.username = '".$name."' AND m.market = '".$market."'"; 
		$db2->query($sql);
		$resultset['result'] = $db2->resultset();
		return $resultset['result'];    
	}
	
	function addMarket($data) {
		global $db2;	
		$sql = "insert into mst_market (market_name, subregion) values ('".$data['market_name']."','".$data['subregion']."')"; 
		$db2->query($sql);
		$result=$db2->execute();
		return $result;		
	}
	function deleteregengnrmarket($data) {
		global $db2;
		if($data['market']!='' && $data['username']!='')
		{
			$sql = "delete from regengnrmarket where username = '".$data['username']."' and market = '".$data['market']."'";  
		}
		else if($data['username']=='')
		{
			$sql = "delete from regengnrmarket where market = '".$data['market']."'";  
		}
		else{
			$sql = "delete from regengnrmarket where username = '".$data['username']."'"; 
		}
		 
		$db2->query($sql);
		$result=$db2->execute(); 
		return $result; 
			
	}
	
	function updateregengnrmarket($data){
		global $db2;
		//$sql = "UPDATE regengnrmarket SET market = '".$data['market']."' where username = '".$data['username']."'";
		$sql = "UPDATE regengnrmarket SET market = '".$data['newmarket']."' where username = '".$data['username']."' and market = '".$data['oldmarket']."'";
		$db2->query($sql);
		$result=$db2->execute(); 
		return $result; 
	}

?>	
