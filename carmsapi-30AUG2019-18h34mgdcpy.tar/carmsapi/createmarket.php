<?php
include 'classes/db2.class.php';
include 'classes/paginator.class.php';
include 'functions.php';
header("Content-Type:application/json");
$headers = apache_request_headers();
//print_r($headers);
//exit;
logToFile('postmanapi.log', $headers['Authorization']);
/*
if ( strcmp($headers['Authorization'],"Bearer oneemscarmsapi") != 0 ) {
       $response['status'] = 800;
       $response['status_message'] = ' Invalid credentials';
       $response['data'] = 'Market' . $name;
       $json_response = json_encode($response);
       echo $json_response;
 exit;
 };
*/
//$data = array('username' => $_GET['username'], 'passwd' => $_GET['passwd'], 'usertype' => $_GET['usertype'], 'firstname' => $_GET['firstname'], 'lastname' => $_GET['lastname'], 'phoneno' => $_GET['phoneno'], 'emailid' => $_GET['emailid'] );
$data = array('username' => $_GET['username'], 'market' => $_GET['market']);
//$market = getregengnrmarket($data);
//if(!empty($market)){
 //   jsonResponse(200, "market already exist", NULL);
//}else{
    if (! empty($data)) {
		$user=getUser($_GET['username']);
		if(!empty($user))
		{
			$responsemarket = addregengnrmarket($data);
		
			if (empty($responsemarket)) {
				jsonResponse(200, "market Not Added", NULL);
			} else {
				jsonResponse(200, "market Added", $responsemarket);
			}
		}
		else{
			jsonResponse(400, "User does not exist ", NULL);
		}
    } else {
        jsonResponse(400, "Invalid Request", NULL);
    }
//}

/*
 * $status = $_GET['name'];
 * $status_message = "User Not Found";
 * $data = "userdata".$_GET['name'];
 * $response['status']=$status;
 * $response['status_message']=$status_message;
 * $response['data']=$data;
 * $json_response = json_encode($response);
 * echo $json_response;
 */
function jsonResponse($status, $status_message, $data)
{
    //header("HTTP/1.1 " . $status_message);
    $response['status'] = $status;
    $response['status_message'] = $status_message;
    $response['data'] = $data;
    $json_response = json_encode($response);
    echo $json_response;
}
;
?>
