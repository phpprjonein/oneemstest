<?php
/* include '/var/www/html/carmsapi/classes/db2.class.php';
include '/var/www/html/carmsapi/classes/paginator.class.php';
include '/var/www/html/carmsapi/functions.php'; */
include 'classes/db2.class.php';
include 'classes/paginator.class.php';
include 'functions.php';
$name = $_GET['username'];
header("Content-Type:application/json");
$headers = apache_request_headers();
$username = (isset($_GET['username'])) ? $_GET['username'] : "";
$usertype = (isset($_GET['usertype'])) ? $_GET['usertype'] : "";
//logToFile('postmanapi.log', $headers['Authorization']);
/*
if ( strcmp($headers['Authorization'],"Bearer oneemscarmsapi") != 0 ) {
       $response['status'] = 800;
       $response['status_message'] = ' Invalid credentials';
       $response['data'] = 'regengnrmarket' . $name;
       $json_response = json_encode($response);
       echo $json_response;
 exit;
 }; 
*/
$data = array('username' => $_GET['username'],'oldmarket' => $_GET['oldmarket'], 'newmarket' => $_GET['newmarket']);
$data['market'] = $data['oldmarket'];
$userInfo=get_user_info_sso($username);
$userlevel=$userInfo['role'];
$oldmarket=$_GET['oldmarket'];
$market = getregengnrmarket($data);
if (!empty($market)) {
    $name = $_GET['username'];    
	$market = updateregengnrmarket($data);
    jsonResponse(200, "Market Updated", $headers['Authorization']);
	$mesg = "Carms user created User name: $username - $userlevel User type : $usertype Page: Carmsapi - updatemarket : Market $oldmarket Updated.";
	write_log($mesg);
}
else if (empty($market)) {
	jsonResponse(200, "Market Not Found", NULL);
	$mesg = "Carms user created User name: $username - $userlevel User type : $usertype Page: Carmsapi - updatemarket : Market $oldmarket not found.";
	write_log($mesg);
} 
else {
    jsonResponse(400, "Invalid Request", NULL);
	$mesg = "Carms user created User name: $username - $userlevel User type : $usertype Page: Carmsapi - updatemarket : Invalid Request.";
	write_log($mesg);
}
;

/*
 * $status = $_GET['name'];
 * $status_message = "User Not Fsound";
 * $data = "userdata".$_GET['name'];
 * $response['status']=$status;
 * $response['status_message']=$status_message;
 * $response['data']=$data;
 * $json_response = json_encode($response);
 * echo $json_response;
 */
function jsonResponse($status, $status_message, $data)
{
    $username = $_SERVER['PHP_AUTH_USER'];
    $password = $_SERVER['PHP_AUTH_PW'];
   // header("HTTP/1.1 " . $status_message);
    $response['status'] = $status;
    $response['status_message'] = $status_message;
    $response['data'] = $data;
   //Bearer oneemscarmsapi
    $json_response = json_encode($response);
    echo $json_response;
}
;
?>
