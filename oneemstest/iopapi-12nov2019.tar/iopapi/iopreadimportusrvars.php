<?php
/* include '/var/www/html/iopapi/config.inc.php';
include '/var/www/html/iopapi/classes/db2.class.php';
include '/var/www/html/iopapi/classes/paginator.class.php';
include '/var/www/html/iopapi/functions.php'; */
include 'config.inc.php';
include 'classes/db2.class.php';
include 'classes/paginator.class.php';
include 'functions.php';
//$_GET['name'] = 'Golden_purpose1_ASR-920_1533S3_ranvendor2_scripttype2_GreatLakes_Lab_Detroit9';
$headers = apache_request_headers();
$username = (isset($_GET['username'])) ? $_GET['username'] : "";
$userInfo=get_user_info_sso($username);
$userlevel=$userInfo['role'];

if ( strcmp($headers['Authorization'],"Bearer oneemsiopapi") != 0 ) {
       $response['status'] = 800;
       $response['status_message'] = ' Invalid credentials';
       //$response['data'] = 'Template Name' . $name;
       $response['data'] = 'Template Name' . print_r($headers);
       $json_response = json_encode($response);
       echo $json_response;
        //jsonResponse(400, "Invalid credentials", NULL);
       // echo json_encode('hello');
 exit;
 };

 
header("Content-Type:application/json");
//logToFile('postmanapi.log', $headers['Authorization']);

    $results = getallusrvars();
if (count($results) > 0) {
        /* foreach ($results as $key=>$val):
            $newarr[intval($val['elemid']/10)][] = array('elemid' => $val['elemid'], 'elemvalue' => $val['elemvalue'], 'editable' => $val['editable']);
        endforeach; */
        /* foreach ($results as $key=>$val):
            
        endforeach */;
        jsonResponse(200, "Usrvars Found", $results);
		$mesg = "Iop user created User name: $username - $userlevel Page: Iopapi - readimportusrvars : Usrvars found.";
		write_log($mesg);
    } else {
        jsonResponse(400, "Usrvars not Found", NULL);
		$mesg = "Iop user created User name: $username - $userlevel Page: Iopapi - readimportusrvars : Usrvars not found.";
		write_log($mesg);
    }
    ;



/*
 * $status = $_GET['name'];
 * $status_message = "User Not Fsound";
 * $data = "userdata".$_GET['name'];
 * $response['status']=$status;
 * $response['status_message']=$status_message;
 * $response['data']=$data;
 * $json_response = json_encode($response);
 * echo $json_response;
 */
function jsonResponse($status, $status_message, $data)
{
    $username = $_SERVER['PHP_AUTH_USER'];
    $password = $_SERVER['PHP_AUTH_PW'];
    //header("HTTP/1.1 " . $status_message);
    $response['status'] = $status;
    $response['status_message'] = $status_message;
    $response['data'] = $data;
   //Bearer oneemscarmsapi
   /* if ($username != 'admin') {
        $response['status'] = 700;
        $response['status_message'] = ' Invalid credentials';
        $response['data'] = $data . 'Username' . $username . 'Password' . $password;
    }
    ; */
    $json_response = json_encode($response);
    echo $json_response;
}
;
?>
