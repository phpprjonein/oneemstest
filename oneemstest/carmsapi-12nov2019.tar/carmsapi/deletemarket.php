<?php
include 'classes/db2.class.php';
include 'classes/paginator.class.php';
include 'functions.php';
header("Content-Type:application/json");
$datastring = $_POST['customer'];
$data = json_decode(urldecode($datastring));
$data = json_decode(json_encode($data), true);
$data['username'] = $_GET['username'];
$data['market'] = $_GET['market'];
$headers = apache_request_headers();
$username = (isset($_GET['username'])) ? $_GET['username'] : "";
$usertype = (isset($_GET['usertype'])) ? $_GET['usertype'] : "";
logToFile('postmanapi.log', $headers['Authorization']);
/*
if ( strcmp($headers['Authorization'],"Bearer oneemscarmsapi") != 0 ) {
       $response['status'] = 800;
       $response['status_message'] = ' Invalid credentials';
       $response['data'] = 'username' . $name;
       $json_response = json_encode($response);
       echo $json_response;
 exit;
 };
*/
	$data = array('username' => $_GET['username'],'market' => $_GET['market']);
	$marketname=$_GET['market'];
	$userInfo=get_user_info_sso($username);
	$userlevel=$userInfo['role'];
	if (! empty($data['username'])) {
		$market = getregengnrmarket($data);
		if (empty($market)) {
			jsonResponse(100, "Market Not found ", $data);
			$mesg = "Carms user created User name: $username - $userlevel User type : $usertype Page: Carmsapi - deletemarket : Market $marketname not found.";
			write_log($mesg);
		} else {
			$market = deleteregengnrmarket($data);
			jsonResponse(200, "Market deleted ", $data);
			$mesg = "Carms user created User name: $username - $userlevel User type : $usertype Page: Carmsapi - deletemarket : Market $marketname deleted.";
			write_log($mesg);
		}
	}
	else if (! empty($data['market'])) {
		$market = getregengnrmarket($data);
		if (empty($market)) {
			jsonResponse(100, "Market Not found ", $data);
			$mesg = "Carms user created User name: $username - $userlevel User type : $usertype Page: Carmsapi - deletemarket : Market $marketname not found.";
			write_log($mesg);
		} else {
			$market = deleteregengnrmarket($data);
			jsonResponse(200, "Market deleted ", $data);
			$mesg = "Carms user created User name: $username - $userlevel User type : $usertype Page: Carmsapi - deletemarket : Market $marketname deleted.";
			write_log($mesg);
		}
	}else
	{
		jsonResponse(400, "Invalid Request", NULL);
		$mesg = "Carms user created User name: $username - $userlevel User type : $usertype Page: Carmsapi - deletemarket : Invalid request.";
		write_log($mesg);
	}

/*
 * $status = $_GET['name'];
 * $status_message = "User Not Fsound";
 * $data = "userdata".$_GET['name'];
 * $response['status']=$status;
 * $response['status_message']=$status_message;
 * $response['data']=$data;
 * $json_response = json_encode($response);
 * echo $json_response;
 */
function jsonResponse($status, $status_message, $data)
{
    //header("HTTP/1.1 " . $status_message);
    $response['status'] = $status;
    $response['status_message'] = $status_message;
    $response['data'] = $data;
    $json_response = json_encode($response);
    echo $json_response;
}
;
?>
