<?php
/* include '/var/www/html/iopapi/config.inc.php';
include '/var/www/html/iopapi/classes/db2.class.php';
include '/var/www/html/iopapi/classes/paginator.class.php';
include '/var/www/html/iopapi/functions.php'; */
include 'config.inc.php';
include 'classes/db2.class.php';
include 'classes/paginator.class.php';
include 'functions.php';
//$_GET['name'] = 'Golden_purpose1_ASR-920_1533S3_ranvendor2_scripttype2_GreatLakes_Lab_Detroit9';

$name = $_GET['name'];
if(isset($_POST['iop_devicename']))
{
	$_POST['f14']=$_POST['iop_devicename'];
}
if(!isset($_POST['Bandwidth_(Mbps)']))
	$_POST['Bandwidth_(Mbps)']=50;
$bmbps = get_bandwidth_mbpsvalues($_POST['Bandwidth_(Mbps)']);
$headers = apache_request_headers();
// print_r($headers);
 if ( strcmp($headers['Authorization'],"Bearer oneemsiopapi") != 0 ) {
       $response['status'] = 800;
       $response['status_message'] = ' Invalid credentials';
       //$response['data'] = 'Template Name' . $name;
       $response['data'] = 'Template Name' . print_r($headers);
       $json_response = json_encode($response);
       echo $json_response;
        //jsonResponse(400, "Invalid credentials", NULL);
       // echo json_encode('hello');
 exit;
 }; 

$category = $_GET['category'];
header("Content-Type:application/json");
$headers = apache_request_headers();
//print_r($headers);
//exit;
logToFile('postmanapi.log', $headers['Authorization']);

    $results = config_get_templates_from_templname($name);
	if(isset($_POST['iop_switchname']))
		$_POST['f11']=$_POST['iop_switchname'];
    //echo '<pre>';print_r($results);exit;
    foreach ($results as $key=>$val):
		$newarr[intval($val['elemid']/10)][] = array('elemid' => $val['elemid'], 'elemvalue' => $val['elemvalue'], 'editable' => $val['editable'], 'tabname' => $val['tabname']);
	endforeach;
    //print_r($newarr);exit;
	$vars['globalvars'] = configtemplate_elemvalue_pos_script('globalvars', 'gvarname', 'gvarval');//print_r($vars);exit;
	foreach ($vars['globalvars'] as $key => $val) {
		$result['globalvars'][$_POST['iop_switchname'] . $val['gvarname']] = $val['gvarval'];
		for ($k = 1; $k <= count($newarr); $k ++) {
			for ($l = 0; $l < count($newarr[$k]); $l ++) {
				//echo '<br>'.$newarr[$k][$l]["elemvalue"].' & '.$val['gvarname'];
				if ((str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $newarr[$k][$l]["elemvalue"]) == str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $val['gvarname']))) {
					$newarr[$k][$l]["elemvalue"] = $val['gvarval'];//echo 'abcd'.$val['gvarval'];//exit;
				}
			}
		}//exit;
		//$newarr['globalvars'][$_POST['iop_switchname'] . $val['gvarname']] = $val['gvarval'];
	}
	
	/* $vars['usrvars'] = configtemplate_elemvalue_pos_script('usrvars', 'usrvarname', 'usrvarval');
	foreach ($vars['usrvars'] as $key => $val) {
		$value = str_replace(' ', '_', $val['usrvarname']);
		$result['usrvars'][$_POST['iop_switchname'] . $val['usrvarname']] = $_POST[$value];
		for ($k = 1; $k <= count($newarr); $k ++) {
			for ($l = 0; $l < count($newarr[$k]); $l ++) {				
				if ((str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $newarr[$k][$l]["elemvalue"]) == str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $val['usrvarname']))) {
					$newarr[$k][$l]["elemvalue"] = $val['usrvarval'];//echo 'abcd'.$val['gvarval'];//exit;
				}
			}
		}
	} */
	
	$vars['marketvars'] = configtemplate_elemvalue_pos_script_market('marketvars', 'mvarname', 'mvarval', $_POST['f11']);
	
	foreach ($vars['marketvars'] as $key => $val) {
		$result['marketvars'][$_POST['iop_switchname'] . $val['mvarname']] = $val['mvarval'];
		for ($k = 1; $k <= count($newarr); $k ++) {
			for ($l = 0; $l < count($newarr[$k]); $l ++) {
				//echo '<br>'.$newarr[$k][$l]["elemvalue"].' & '.$val['mvarname'];
				if ((str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $newarr[$k][$l]["elemvalue"]) == str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $val['mvarname']))) {
					$newarr[$k][$l]["elemvalue"] = $val['mvarval'];//echo 'abcd'.$val['mvarval'];//exit;
				}
			}
		}
	}//exit;
	
	$vars = configtemplate_elemvalue_pos_script_switch_name($_POST['f11']);
	
	foreach ($vars as $key => $val) {
		$result['switchvars'][$_POST['iop_switchname'] . $val['swvarname']] = $val['swvarval'];
		for ($k = 1; $k <= count($newarr); $k ++) {
			for ($l = 0; $l < count($newarr[$k]); $l ++) {
				//echo '<br>'.$newarr[$k][$l]["elemvalue"].' & '.$val['swvarname'];
				if ((str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $newarr[$k][$l]["elemvalue"]) == str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $val['swvarname']))) {
					$newarr[$k][$l]["elemvalue"] = $val['swvarval'];//echo 'abcd'.$val['swvarval'];//exit;
				}
			}
		}
		//$newarr['switchvars'][$_POST['iop_switchname'] . $val['swvarname']] = $val['swvarval'];
	}
	
	//Pre populate device name
	$result['globalvars'][$_POST['f11'] . 'device name'] = $result['usrvars'][$_POST['f11'] . 'device name'] = $result['marketvars'][$_POST['f11'] . 'device name'] = $result['switchvars'][$_POST['f11'] . 'device name'] = $_POST['f14'];
	//$newarr['globalvars'][$_POST['f11'] . 'device name'] = $newarr['usrvars'][$_POST['f11'] . 'device name'] = $newarr['marketvars'][$_POST['f11'] . 'device name'] = $newarr['switchvars'][$_POST['f11'] . 'device name'] = $_POST['f14'];
	//$newarr['globalvars']['device name']=$_POST['f14'];
	//print_r($newarr);exit;
	for ($k = 1; $k <= count($newarr); $k ++) {
		if(isset($_POST)){		
			$uservar = $_POST;
			foreach ($uservar as $keytab => $valtab){
				if (count($newarr[$k]) == 1) {
					$output .= '<div class="form-group">';
					if ($newarr[$k][0]["editable"] == 0) {
						if(strpos($newarr[$k][0]["elemvalue"], 'ASR9010-01') || strpos($newarr[$k][0]["elemvalue"], 'ASR9010-02')){
							$output .= '<div class="jf-form form-group col-xs-10 col-sm-3 col-md-3 col-lg-12 alert alert-secondary panel-heading-lstmgmt"><b>'.$newarr[$k][0]["elemvalue"].'</b></div>';
						}
						
						$output .= "<input type='text' style='display:none !important;' name='loop[looper_" . $k . "][]' value='" . $newarr[$k][0]["elemvalue"] . "'><span class='form-non-editable-fields'><label class='readonly'>" . $newarr[$k][0]["elemvalue"] . "</label></span>";
					} else {
						$pink_box_size = strlen($result[$newarr[$k][0]["tabname"]][$_POST['f11'] . $newarr[$k][0]["elemvalue"]]);
						$pink_box_size = ($pink_box_size == 0 || $pink_box_size < $pink_box_min_size) ? $pink_box_min_size : $pink_box_size;
						$editable = 1;
						
						if (strpos($keytab, 'iop') !== false) {
							$tempnamearray=explode("_",$keytab);
							if(str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $tempnamearray[1])==str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $newarr[$k][0]["elemvalue"]))
							{	
								$newarr[$k][0]["elemvalue"]=$valtab;
								$loop["looper_" . $k ][0]["elemvalue"]=$result[$newarr[$k][0]["tabname"]][$_POST['f11'] . $newarr[$k][0]["elemvalue"]];
							}
							if(strpos($newarr[$k][0]["elemvalue"],'vars')){
									$elemvalarr=explode(" ",$newarr[$k][0]["elemvalue"]);
									$newelemvalarr=array_shift($elemvalarr);//print_r($elemvalarr);
									$newElementVal='';//echo count($elemvalarr);
									for($s=0;$s<=count($elemvalarr);$s++){$newElementVal.=' '.$elemvalarr[$s];}
									echo $newElementVal;
									if(str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $newElementVal)==str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $tempnamearray[1]))
									{	
										$newarr[$k][0]["elemvalue"]=$valtab;
										$newarr[$k][1]["elemvalue"]=$valtab;
										$loop["looper_" . $k ][0]["elemvalue"]=$result[$newarr[$k][0]["tabname"]][$_POST['f11'] . $newarr[$k][0]["elemvalue"]];
									}
								}
						}
						if(str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $newarr[$k][0]["elemvalue"]) == str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $keytab)){
							$newarr[$k][0]["elemvalue"]=$valtab;
							$loop['looper_'.$k][0]["elemvalue"]=$result[$newarr[$k][0]["tabname"]][$_POST['f11'] . $newarr[$k][0]["elemvalue"]];
						}	
						$output .= "<span class='form-editable-fields'><input type='text' size='" . $pink_box_size . "'  name='loop[looper_" . $k . "][]' class='form-control cellsitech-configtxtinp border border-dark' value='" . $result[$newarr[$k][0]["tabname"]][$_POST['f11'] . $newarr[$k][0]["elemvalue"]] . "'></span>";
					}			
												
					
					$output .= '</div>';
				} else {
					$output .= '<div class="form-group">';
					$editable = 0;
					$outputin = '';
			//echo '<br>'.$keytab.' & '.str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $keytab);
					$elemid = $keytab;
					$elemvalue = $valtab;
					for ($l = 0; $l < count($newarr[$k]); $l ++) {
						if ($newarr[$k][$l]["editable"] == 0) {
							$rowval = generatescript_str_preprocess($newarr[$k][$l]["elemvalue"], $bmbps);							
							$newarr[$k][$l]["elemvalue"]=$rowval;
							
						} else {
							$editable = 1;
							
							if (strpos($keytab, 'iop') !== false) {//echo $keytab.' : '.$newarr[$k][$l]["elemvalue"];
								$tempnamearray=explode("_",$keytab);
								if(str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $tempnamearray[1])==str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $newarr[$k][$l]["elemvalue"]))
								{	
									$newarr[$k][$l]["elemvalue"]=$valtab;
									$loop["looper_" . $k ][$l]["elemvalue"]=$result[$newarr[$k][$l]["tabname"]][$_POST['f11'] . $newarr[$k][$l]["elemvalue"]];
								}
								if(strpos($newarr[$k][$l]["elemvalue"],'vars')){
									$elemvalarr=explode(" ",$newarr[$k][$l]["elemvalue"]);
									$newelemvalarr=array_shift($elemvalarr);//print_r($elemvalarr);
									$newElementVal='';//echo count($elemvalarr);
									for($s=0;$s<=count($elemvalarr);$s++){$newElementVal.=' '.$elemvalarr[$s];}
									echo $newElementVal;
									if(str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $newElementVal)==str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $tempnamearray[1]))
									{	
										$newarr[$k][$l]["elemvalue"]=$valtab;
										$newarr[$k][$l+1]["elemvalue"]=$valtab;
										$loop["looper_" . $k ][$l]["elemvalue"]=$result[$newarr[$k][$l]["tabname"]][$_POST['f11'] . $newarr[$k][$l]["elemvalue"]];
									}
								}
							}
							if(str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $newarr[$k][$l]["elemvalue"]) == str_replace( array( '\'', '"', '_' , '-', '<', '>','(',')',' ' ), '', $keytab)){
								$newarr[$k][$l]["elemvalue"]=$valtab;
								$loop['looper_'.$k][$l]["elemvalue"]=$result[$newarr[$k][$l]["tabname"]][$_POST['f11'] . $newarr[$k][$l]["elemvalue"]];
							}							
						}if($newarr[$k][$l]["elemvalue"]=='BGP Password')
							$newarr[$k][$l]["elemvalue"]='';
						if($newarr[$k][$l]["tabname"]=='marketvars' && $newarr[$k][$l]["elemvalue"]!='tbd')							
							$newarr[$k][$l]["elemvalue"]='';
						if($newarr[$k][$l]["elemvalue"]=='mktvars snmp server1 ')
							$newarr[$k][$l+1]["elemvalue"]='tbd';
					}//exit;
				}
			}//exit;
		}
	}
	if(strpos($newarr[1][0]["elemvalue"],'device') && $newarr[1][1]["elemvalue"] =='')
	{
		$newarr[1][1]["elemvalue"]=$_POST['iop_devicename'];
	}
    
    //print_r($newarr);exit;
    $fileDetails=download_script($name,$newarr);
	//$fileData=array('filename' => __DIR__ .$fileDetails.'script', 'zip' => __DIR__ .$fileDetails);
	//$fileData=array('filename' => __DIR__ .$fileDetails.'script', 'zip' => urlencode(stripslashes($fileDetails)));
	//$fileData=array('filename' => $fileDetails.'script', 'zip' => $fileDetails);
	$fileData=array('zip' => $fileDetails);
			
	if (empty($fileDetails)) {
		jsonResponse(200, "Generate script Failed", NULL);
	} else {
		jsonResponse(200, "Generate script Success", $fileData);
	}
    //print json_encode($line_arr);
    
    
    

/*
 * $status = $_GET['name'];
 * $status_message = "User Not Fsound";
 * $data = "userdata".$_GET['name'];
 * $response['status']=$status;
 * $response['status_message']=$status_message;
 * $response['data']=$data;
 * $json_response = json_encode($response);
 * echo $json_response;
 */
function jsonResponse($status, $status_message, $data)
{
    $username = $_SERVER['PHP_AUTH_USER'];
    $password = $_SERVER['PHP_AUTH_PW'];
    //header("HTTP/1.1 " . $status_message);
    $response['status'] = $status;
    $response['status_message'] = $status_message;
    $response['data'] = $data;
   //Bearer oneemscarmsapi
   /* if ($username != 'admin') {
        $response['status'] = 700;
        $response['status_message'] = ' Invalid credentials';
        $response['data'] = $data . 'Username' . $username . 'Password' . $password;
    }
    ; */
    //$json_response = json_encode($response);
    $json_response = json_encode($response,JSON_UNESCAPED_SLASHES);
    echo $json_response;
}
;
?>
