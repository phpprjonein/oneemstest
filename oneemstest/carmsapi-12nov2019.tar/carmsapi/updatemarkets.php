<?php
include 'classes/db2.class.php';
include 'classes/paginator.class.php';
include 'functions.php';
/* include '/var/www/html/carmsapi/classes/db2.class.php';
include '/var/www/html/carmsapi/classes/paginator.class.php';
include '/var/www/html/carmsapi/functions.php'; */
$name = $_GET['name'];
header("Content-Type:application/json");
$headers = apache_request_headers();
$username = (isset($_GET['username'])) ? $_GET['username'] : "";
$usertype = (isset($_GET['usertype'])) ? $_GET['usertype'] : "";
logToFile('postmanapi.log', $headers['Authorization']);
$userInfo=get_user_info_sso($username);
$userlevel=$userInfo['role'];
/*
if ( strcmp($headers['Authorization'],"Bearer oneemscarmsapi") != 0 ) {
       $response['status'] = 800;
       $response['status_message'] = ' Invalid credentials';
       $response['data'] = 'Username' . $name;
       $json_response = json_encode($response);
       echo $json_response;
 exit;
 }; 
*/
$user = getUser($name);
if (! empty($_GET['name'])) {
    $name = $_GET['name'];
    $data['username'] = $_GET['name'];
    $data['markets'] = $_GET['markets'];
    $user = getUser($name);
    $userattributes =  updateMarkets($data);
    if (empty($user)) {
        jsonResponse(200, "User Not Found", NULL);
		$mesg = "Carms user created User name: $username - $userlevel User type : $usertype Page: Carmsapi - updatemarkets : User $username not found.";
		write_log($mesg);
    } else {
        //jsonResponse(200, "User Found", $headers['Authorization']);
        jsonResponse(200, "User Found", $userattributes);
		$mesg = "Carms user created User name: $username - $userlevel User type : $usertype Page: Carmsapi - updatemarkets : User $username found.";
		write_log($mesg);
    }
} else {
    jsonResponse(400, "Invalid Request", NULL);
	$mesg = "Carms user created User name: $username - $userlevel User type : $usertype Page: Carmsapi - updatemarkets : Invalid Request.";
	write_log($mesg);
}
;

/*
 * $status = $_GET['name'];
 * $status_message = "User Not Fsound";
 * $data = "userdata".$_GET['name'];
 * $response['status']=$status;
 * $response['status_message']=$status_message;
 * $response['data']=$data;
 * $json_response = json_encode($response);
 * echo $json_response;
 */
function jsonResponse($status, $status_message, $data)
{
    $username = $_SERVER['PHP_AUTH_USER'];
    $password = $_SERVER['PHP_AUTH_PW'];
    header("HTTP/1.1 " . $status_message);
    $response['status'] = $status;
    $response['status_message'] = $status_message;
    $response['data'] = $data;
   //Bearer oneemscarmsapi
    $json_response = json_encode($response);
    echo $json_response;
}
;
?>
