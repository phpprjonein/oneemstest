<?php

function logToFile($filename, $msg) {
    // open file
    $fd = fopen($filename, "a");
    // append date/time to message
    $str = "[" . date("Y/m/d h:i:s", mktime()) . "] " . $msg;
    // write string
    fwrite($fd, $str . "\n");
    // close file
    fclose($fd);
}

/**
 *
 * @param unknown $message
 * @param string $logfile
 * @return boolean[]|string[]|boolean[]
 */
	function write_log($message, $logfile = '')
	{
    if (isset($_SESSION['impusername']) && ! empty($_SESSION['impusername'])) {
        $message = $message . ', Impersonate Set, Admin User name:' . $_SESSION['impusername'];
    }
    
    // Determine log file
    // Filename of log to use when none is given to write_log
    /* $default_log = "/usr/apps/oneems/logs/oneemsdefault_" . date(m_d_Y) . ".log";
    $upload_log = "/usr/apps/oneems/logs/oneems_" . date(m_d_Y) . ".log"; */
	//$default_log = "log/oneemsdefault_" . date(m_d_Y) . ".log";
    //$upload_log = "logs/oneems_" . date(m_d_Y) . ".log";
    // $default_log = "O:\wamp\www\oneems\logs\oneemsdefault_" . date(m_d_Y) . ".log";
    // $upload_log = "O:\wamp\www\oneems\logs\oneems_" . date(m_d_Y) . ".log";
    $default_log = "/usr/apps/oneems/logs/carms/oneemsdefault_" . date(m_d_Y) . ".log";
    $upload_log = "/usr/apps/oneems/logs/carms/oneems_" . date(m_d_Y) . ".log";

    // echo 'reach here inside the write_log function';
    
    if ($logfile == '') {
        // checking if the constant for the log file is defined
        if (isset($default_log)) {
            $logfile = $default_log;
        } // the constant is not defined and there is no log file given as input
        else {
            error_log('No log file defined!', 0);
            return array(
                status => false,
                message => 'No log file defined!'
            );
        }
    }
    
    // Get time of request
    if (($time = $_SERVER['REQUEST_TIME']) == '') {
        $time = time();
    }
    
    // Get IP address
    if (($remote_addr = $_SERVER['REMOTE_ADDR']) == '') {
        $remote_addr = "REMOTE_ADDR_UNKNOWN";
    }
    
    // Get requested script
    if (($request_uri = $_SERVER['REQUEST_URI']) == '') {
        $request_uri = "REQUEST_URI_UNKNOWN";
    }
    
    // Format the date and time
    $date = date("Y-m-d H:i:s", $time);
    
    // Append to the log file
    if ($fd = @fopen($logfile, "a")) {
        $result = fputcsv($fd, array(
            $date,
            $remote_addr,
            $request_uri,
            $message
        ), '|');
        fclose($fd);
        
        if ($result > 0)
            return array(
                status => true
            );
        else
            return array(
                status => false,
                message => 'Unable to write to ' . $logfile . '!'
            );
    } else {
        return array(
            status => false,
            message => 'Unable to open log ' . $logfile . '!'
        );
    }
}
	function getUser($name) {
		global $db2;	
			//$sql = "SELECT id, p.name, p.description, p.price, p.created FROM items p WHERE p.name LIKE '%".$name."%' ORDER BY p.created DESC";
				//$sql = "select id, username, password, userlevel,fname,lname,phone from users p WHERE p.username = '".$name."'"; 
		$sql = "select id, username, userlevel from users p WHERE p.username = '".$name."'"; 
		$db2->query($sql);
		$resultset['result'] = $db2->resultset();
		return  $resultset['result'];    
	}
			  //[username] => ssf [password] => k [usertype] => k [firstname] => k [lastname] => k [phoneno] => k [emailid] => k ) 
	function addUser($data) {
		global $db2;	
		$sql = "insert into users (username, password, userid, userlevel, email, status, fname, lname, phone ) values ('".$data['username']."','".md5($data['password'])."','".$data['username']."','".$data['usertype']."','".$data['emailid']."','1','".$data['firstname']."','".$data['lastname']."','".$data['phoneno']."')"; 
		 //$data = array("username" => $_POST['uname'],"password" => $_POST['passwd'],"usertype" => $_POST['usertype'],"firstname"=>$_POST['firstname'],"lastname" => $_POST['lname'],"phoneno" => $_POST['phoneno'],"emailid" => $_POST['emailid']);
			//$sql = "insert into users ( username, password, userid, userlevel, email, fname, lname, phone ) values ('".$data['username']."''".$data['password']."''"..$data['userid']."''".$data['userlevel']."''".$data['email']."''".$data['fname']."''".$data['lname']."''".$data['phoneno']."')";
		$db2->query($sql);
		$result=$db2->execute();
		   
			//$resultset['result'] = $db2->resultset();
			//return  $resultset['result'];    
		return $result;
			  //$data = json_decode($data);
			 // echo $result;  
			 //print_r($data);
			 //echo json_encode($sql);
	} 
		
	function addregengnrmarket($data){
		global $db2;
		$sql = "insert into regengnrmarket (username, market) values ('".$data['username']."','".$data['market']."')"; 
			 
		$db2->query($sql);
		$result=$db2->execute();
		
		return $result;
	}
	
	function deleteUser($data) {
		global $db2;	
		$user = getUser($data['username']);
		$sql = "delete from users where username = '".$data['username']."'";  
		$db2->query($sql);
		$result=$db2->execute(); 
		//if($user['userlevel']==5)
		//{
			$sql1 = "delete from regengnrmarket where username = '".$data['username']."'";  
			$db2->query($sql1);
			$result1=$db2->execute(); 
			$sql1 = "delete from users where username = '".$data['username']."'";  
			$db2->query($sql1);
			$result1=$db2->execute(); 
		//}
		return $result; 
			
	}  

     // Begins
    function getMarkets($name) {
		global $db2;
		$sql = "select market from regengnrmarket p WHERE p.username = '".$name."'";
		$db2->query($sql);
		$resultset = $db2->resultset();
		return  $resultset;
    }

      //Ends

	function updateMarkets($data) {
		global $db2;	
		$sql = "delete from regengnrmarket p WHERE p.username = '".$data['username']."'"; 
		$db2->query($sql);
		$result1=$db2->execute(); 
		//$sql = "insert into regengnrmarket (username, markets ) values ('".$data['username']."','".$data['markets'])."')"; 
		$sql = "insert into regengnrmarket (username, markets ) values ('".$data['username']."','".$data['markdets']."')";
		$db2->query($sql);
		$result=$db2->execute();
	}

	function getregengnrmarket($data) {
		global $db2;	
		$name=$data['username'];
		$market=$data['market'];
		if(!isset($market))
			$sql = "select market, username from regengnrmarket m WHERE m.username = '".$name."'";
		else		
			$sql = "select market, username from regengnrmarket m WHERE m.username = '".$name."' AND m.market = '".$market."'"; 
		$db2->query($sql);
		$resultset['result'] = $db2->resultset();
		return $resultset['result'];    
	}
	
	function addMarket($data) {
		global $db2;	
		$sql = "insert into mst_market (market_name, subregion) values ('".$data['market_name']."','".$data['subregion']."')"; 
		$db2->query($sql);
		$result=$db2->execute();
		return $result;		
	}
	
	function deleteregengnrmarket($data) {
		global $db2;
		if($data['market']!='' && $data['username']!='')
		{
			$sql = "delete from regengnrmarket where username = '".$data['username']."' and market = '".$data['market']."'";  
		}
		else if($data['username']=='')
		{
			$sql = "delete from regengnrmarket where market = '".$data['market']."'";  
		}
		else{
			$sql = "delete from regengnrmarket where username = '".$data['username']."'"; 
		}
		 
		$db2->query($sql);
		$result=$db2->execute(); 
		return $result; 
			
	}
	
	function updateregengnrmarket($data){
		global $db2;
		//$sql = "UPDATE regengnrmarket SET market = '".$data['market']."' where username = '".$data['username']."'";
		$sql = "UPDATE regengnrmarket SET market = '".$data['newmarket']."' where username = '".$data['username']."' and market = '".$data['oldmarket']."'";
		$db2->query($sql);
		$result=$db2->execute(); 
		return $result; 
	}

	function replaceregengnrmarketlist($data){
		global $db2;
	//	$sql = "delete from regengnrmarket  where username = '".$data['username']."'";  
	//	$db2->query($sql);
//		$result=$db2->execute(); 
		$sql = "insert into regengnrmarket (username, market) values ('".$data['username']."','".$data['market']."')"; 
		$db2->query($sql);
		$result=$db2->execute();
		return $result;
	}

	function deleterallegengnrmarkets($data) {
		global $db2;
	    $sql = "delete from regengnrmarket where username = '".$data['username']."'"; 
		$db2->query($sql);
		$result=$db2->execute(); 
		return $result; 
	}
	
	/**
	 *
	 * @param unknown $username
	 * @return unknown|boolean
	 */
	function get_user_info_sso($username)
	{
		global $db2;
		
		if (trim($username) != '') {
			$sql = "SELECT u.*,ul.userlevel as role FROM users u, userlevels ul WHERE u.username='" . $username . "' AND ul.id = u.userlevel AND
	u.status = 1";
			$db2->query($sql);
			$rows = $db2->resultset();
			$result = $rows[0];
			return $result;
		}
		return false;
	}
?>	
