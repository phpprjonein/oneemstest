<?php

function logToFile($filename, $msg) {
    // open file
    $fd = fopen($filename, "a");
    // append date/time to message
    $str = "[" . date("Y/m/d h:i:s", mktime()) . "] " . $msg;
    // write string
    fwrite($fd, $str . "\n");
    // close file
    fclose($fd);
}

	function getUser($name) {
			global $db2;	
			//$sql = "SELECT id, p.name, p.description, p.price, p.created FROM items p WHERE p.name LIKE '%".$name."%' ORDER BY p.created DESC";
				//$sql = "select id, username, password, userlevel,fname,lname,phone from users p WHERE p.username = '".$name."'"; 
				$sql = "select id, username, userlevel from users p WHERE p.username = '".$name."'"; 
				$db2->query($sql);
			   $resultset['result'] = $db2->resultset();
				return  $resultset['result'];    
	}
			  //[username] => ssf [password] => k [usertype] => k [firstname] => k [lastname] => k [phoneno] => k [emailid] => k ) 
	function addUser($data) {
			global $db2;	
			$sql = "insert into users (username, password, userid, userlevel, email, status, fname, lname, phone ) values ('".$data['username']."','".md5($data['password'])."','".$data['username']."','".$data['usertype']."','".$data['emailid']."','1','".$data['firstname']."','".$data['lastname']."','".$data['phoneno']."')"; 
			 //$data = array("username" => $_POST['uname'],"password" => $_POST['passwd'],"usertype" => $_POST['usertype'],"firstname"=>$_POST['firstname'],"lastname" => $_POST['lname'],"phoneno" => $_POST['phoneno'],"emailid" => $_POST['emailid']);
			    //$sql = "insert into users ( username, password, userid, userlevel, email, fname, lname, phone ) values ('".$data['username']."''".$data['password']."''"..$data['userid']."''".$data['userlevel']."''".$data['email']."''".$data['fname']."''".$data['lname']."''".$data['phoneno']."')";
			   $db2->query($sql);
			   $result=$db2->execute();
			   
			    //$resultset['result'] = $db2->resultset();
				//return  $resultset['result'];    
				 return $result;
				  //$data = json_decode($data);
				 // echo $result;  
				 //print_r($data);
				 //echo json_encode($sql);
	} 
		
	function addregengnrmarket($data){
		global $db2;
		$sql = "insert into regengnrmarket (username, market) values ('".$data['username']."','".$data['market']."')"; 
			 
		$db2->query($sql);
		$result=$db2->execute();
		
		return $result;
	}
	
	function deleteUser($data) {
		global $db2;	
		$user = getUser($data['username']);
		$sql = "delete from users where username = '".$data['username']."'";  
		$db2->query($sql);
		$result=$db2->execute(); 
		if($user['userlevel']==5)
		{
			$sql1 = "delete from regengnrmarket where username = '".$data['username']."'";  
			$db2->query($sql1);
			$result1=$db2->execute(); 
		}
		return $result; 
			
	}  

?>	
