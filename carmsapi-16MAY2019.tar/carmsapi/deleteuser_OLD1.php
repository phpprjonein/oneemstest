<?php
include 'classes/db2.class.php';
include 'classes/paginator.class.php';
include 'functions.php';
header("Content-Type:application/json");
$datastring = $_POST['customer'];
$data = json_decode(urldecode($datastring));
$data = json_decode(json_encode($data), true);
$data['username'] = $_GET['username'];
$headers = apache_request_headers();
//print_r($headers);
//exit;
logToFile('postmanapi.log', $headers['Authorization']);
if ( strcmp($headers['Authorization'],"Bearer oneemscarmsapi") != 0 ) {
       $response['status'] = 800;
       $response['status_message'] = ' Invalid credentials';
       $response['data'] = 'Username' . $name;
       $json_response = json_encode($response);
       echo $json_response;
 exit;
 };

if (! empty($data['username'])) {
    $user = deleteUser($data);
    if (empty($user)) {
        jsonResponse(100, "User Not found".$user, NULL);
    } else {
        jsonResponse(200, "User deleted".$user, $user);
    }
} else {
    jsonResponse(400, "Invalid Request", NULL);
}
;

/*
 * $status = $_GET['name'];
 * $status_message = "User Not Fsound";
 * $data = "userdata".$_GET['name'];
 * $response['status']=$status;
 * $response['status_message']=$status_message;
 * $response['data']=$data;
 * $json_response = json_encode($response);
 * echo $json_response;
 */
function jsonResponse($status, $status_message, $data)
{
    header("HTTP/1.1 " . $status_message);
    $response['status'] = $status;
    $response['status_message'] = $status_message;
    $response['data'] = $data;
    $json_response = json_encode($response);
    echo $json_response;
}
;
?>
