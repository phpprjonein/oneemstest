#!/bin/sh
echo 'Shell program is executing '
#ls
echo 'Before Changing the hostname'
grep -r --include=*.php "carmsapi"
echo 'After Changing the hostname'
find ./ -type f -exec sed -i -e 's/carmsapi/carmsapi/g' {} \;
