<?php
include 'classes/db2.class.php';
include 'classes/paginator.class.php';
include 'functions.php';
header("Content-Type:application/json");
$headers = apache_request_headers();
//print_r($headers);
//exit;
logToFile('postmanapi.log', $headers['Authorization']);
/*
if ( strcmp($headers['Authorization'],"Bearer oneemscarmsapi") != 0 ) {
       $response['status'] = 800;
       $response['status_message'] = ' Invalid credentials';
       $response['data'] = 'Username' . $name;
       $json_response = json_encode($response);
       echo $json_response;
 exit;
 };
*/
//$data = array('username' => $_GET['username'], 'passwd' => $_GET['passwd'], 'usertype' => $_GET['usertype'], 'firstname' => $_GET['firstname'], 'lastname' => $_GET['lastname'], 'phoneno' => $_GET['phoneno'], 'emailid' => $_GET['emailid'] );
$data = array('username' => $_GET['username'], 'password' => 'OneEMSPass!!', 'usertype' => $_GET['usertype'], 'firstname' => $_GET['firstname'], 'lastname' => $_GET['lastname'], 'phoneno' => $_GET['phoneno'], 'emailid' => $_GET['emailid'] );
$user = getUser($_GET['username']);
if(!empty($user)){
    jsonResponse(200, "User already exist", NULL);
}else{
    if (! empty($data)) {
        $user = addUser($data);
		if($_GET['usertype']==5)
		{
			$marketsData=$_GET['markets'];
			if($marketsData!='')
			{
				$markets_array=explode(',', $marketsData);
				foreach($markets_array as $market)
				{
					$market_data = array('username' => $_GET['username'],'market' => $market);
					$markets = addregengnrmarket($market_data);
				}
			}
		}
        if (empty($user)) {
            jsonResponse(200, "User Not Added", NULL);
        } else {
			if($_GET['markets'])
				jsonResponse(200, "User Added with market data", $user);
			else
				jsonResponse(200, "User Added", $user);
        }
    } else {
        jsonResponse(400, "Invalid Request", NULL);
    }
}

/*
 * $status = $_GET['name'];
 * $status_message = "User Not Found";
 * $data = "userdata".$_GET['name'];
 * $response['status']=$status;
 * $response['status_message']=$status_message;
 * $response['data']=$data;
 * $json_response = json_encode($response);
 * echo $json_response;
 */
function jsonResponse($status, $status_message, $data)
{
    //header("HTTP/1.1 " . $status_message);
    $response['status'] = $status;
    $response['status_message'] = $status_message;
    $response['data'] = $data;
    $json_response = json_encode($response);
    echo $json_response;
}
;
?>
