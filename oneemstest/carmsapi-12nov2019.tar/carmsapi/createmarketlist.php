<?php
include 'classes/db2.class.php';
include 'classes/paginator.class.php';
include 'functions.php';
header("Content-Type:application/json");
$headers = apache_request_headers();
$username = (isset($_GET['username'])) ? $_GET['username'] : "";
$usertype = (isset($_GET['usertype'])) ? $_GET['usertype'] : "";

logToFile('postmanapi.log', $headers['Authorization']);
/*
if ( strcmp($headers['Authorization'],"Bearer oneemscarmsapi") != 0 ) {
       $response['status'] = 800;
       $response['status_message'] = ' Invalid credentials';
       $response['data'] = 'Market' . $name;
       $json_response = json_encode($response);
       echo $json_response;
 exit;
 };
*/
//$data = array('username' => $_GET['username'], 'passwd' => $_GET['passwd'], 'usertype' => $_GET['usertype'], 'firstname' => $_GET['firstname'], 'lastname' => $_GET['lastname'], 'phoneno' => $_GET['phoneno'], 'emailid' => $_GET['emailid'] );
$data = array('username' => $_GET['username'], 'markets' => $_GET['markets'], 'usertype' => $_GET['usertype']);
$userInfo=get_user_info_sso($username);
$userlevel=$userInfo['role'];
$marketname=$_GET['market'];
    if (! empty($data)) {
		$user=getUser($_GET['username']);
		if(!empty($user))
		{
			//Begins
			if($_GET['usertype']==5)
            {
                $marketsData=$_GET['markets'];
                if($marketsData!='')
                {
					$markets_array=explode(',', $marketsData);
					$response = deleterallegengnrmarkets($data);
					foreach($markets_array as $market)
					{
							$market_data = array('username' => $_GET['username'],'market' => $market);
							//$markets = addregengnrmarket($market_data);
							$markets = replaceregengnrmarketlist($market_data);
					}
				}
            }
			//ENDS
			if (empty($markets)) {
				jsonResponse(200, "market Not Added", NULL);
				$mesg = "Carms user created User name: $username - $userlevel User type : $usertype Page: Carmsapi - createmarketlist : Market $marketname not added.";
				write_log($mesg);
			} else {
				jsonResponse(200, "market Added", $responsemarket);
				$mesg = "Carms user created User name: $username - $userlevel User type : $usertype Page: Carmsapi - createmarketlist : Market $marketname added.";
				write_log($mesg);
			}
		}
		else{
			jsonResponse(400, "User does not exist ", NULL);
			$mesg = "Carms user created User name: $username - $userlevel User type : $usertype Page: Carmsapi - createmarketlist : User $username Does not exist.";
			write_log($mesg);
		}
    } else {
        jsonResponse(400, "Invalid Request", NULL);
		$mesg = "Carms user created User name: $username - $userlevel User type : $usertype Page: Carmsapi - createmarketlist : Invalid request";
		write_log($mesg);
    }
//}

/*
 * $status = $_GET['name'];
 * $status_message = "User Not Found";
 * $data = "userdata".$_GET['name'];
 * $response['status']=$status;
 * $response['status_message']=$status_message;
 * $response['data']=$data;
 * $json_response = json_encode($response);
 * echo $json_response;
 */
function jsonResponse($status, $status_message, $data)
{
    //header("HTTP/1.1 " . $status_message);
    $response['status'] = $status;
    $response['status_message'] = $status_message;
    $response['data'] = $data;
    $json_response = json_encode($response);
    echo $json_response;
}
;
?>
