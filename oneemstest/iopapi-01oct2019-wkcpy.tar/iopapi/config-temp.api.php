<?php
include "classes/db2.class.php";
include "classes/paginator.class.php";  
include 'functions.php'; 
//echo ($_POST['data']);
echo json_encode(array("sa  route-target import XXXXX:4aa019", "one two enable secret edwardXXXXXXXXXX", "", "", "hello service XXXXX-1 evc EVCYYYY", " service XXXXX-2 evc EVCYYYY"));

?>
